const API = "https://openlibrary.org/search.json";
const COVER = "https://covers.openlibrary.org/b/id/";
const grid = document.getElementById("booksGrid");
const notice = document.getElementById("notice");
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const loadMore = document.getElementById("loadMore");
const dialog = document.getElementById("bookDialog");
const dialogContent = document.getElementById("dialogContent");
let currentQuery = "subject:fiction";
let currentPage = 1;
let currentDocs = [];
let favorites = readFavorites();
let favoritesMode = false;

function readFavorites(){ try{return JSON.parse(localStorage.getItem("danai-favorites")||"[]")}catch{return []} }
function saveFavorites(){localStorage.setItem("danai-favorites",JSON.stringify(favorites));updateFavCount()}
function updateFavCount(){document.getElementById("favCount").textContent=favorites.length}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function coverUrl(doc){return doc.cover_i ? `${COVER}${doc.cover_i}-M.jpg` : ""}
function coverMarkup(doc, large=false){
  const url=coverUrl(doc), title=escapeHtml(doc.title||"کتاب");
  return url ? `<img loading="lazy" src="${url}" alt="جلد ${title}" onerror="this.outerHTML='<div class=&quot;cover-placeholder&quot;><div><span>📚</span>${title}</div></div>'">` : `<div class="cover-placeholder"><div><span>📚</span>${title}</div></div>`;
}
function isFav(doc){return favorites.some(x=>x.key===(doc.key||doc.title))}
function toggleFav(doc){
 const key=doc.key||doc.title;
 if(isFav(doc)) favorites=favorites.filter(x=>x.key!==key);
 else favorites.unshift({key,title:doc.title||"بدون نام",author_name:doc.author_name||[],first_publish_year:doc.first_publish_year,cover_i:doc.cover_i,edition_key:doc.edition_key||[],subject:doc.subject||[]});
 saveFavorites();
 if(favoritesMode) renderFavorites(); else renderBooks(currentDocs);
}
function card(doc){
 const saved=isFav(doc), author=(doc.author_name||["نویسنده نامشخص"]).slice(0,2).join("، ");
 return `<article class="book-card">
   <div class="cover-wrap">${coverMarkup(doc)}<button class="fav ${saved?"saved":""}" data-fav="${escapeHtml(doc.key||doc.title)}" aria-label="${saved?"حذف از علاقه‌مندی":"افزودن به علاقه‌مندی"}">${saved?"♥":"♡"}</button></div>
   <h3>${escapeHtml(doc.title||"بدون عنوان")}</h3><p class="author">${escapeHtml(author)}</p>
   <div class="card-bottom"><button data-open="${escapeHtml(doc.key||doc.title)}">جزئیات کتاب</button><span class="year">${doc.first_publish_year||"—"}</span></div>
 </article>`;
}
function bindCards(docs){
 grid.querySelectorAll("[data-fav]").forEach(btn=>btn.addEventListener("click",e=>{e.stopPropagation();const doc=docs.find(d=>(d.key||d.title)===btn.dataset.fav)||favorites.find(d=>(d.key||d.title)===btn.dataset.fav);if(doc)toggleFav(doc)}));
 grid.querySelectorAll("[data-open]").forEach(btn=>btn.addEventListener("click",()=>{const doc=docs.find(d=>(d.key||d.title)===btn.dataset.open)||favorites.find(d=>(d.key||d.title)===btn.dataset.open);if(doc)showDetails(doc)}));
}
function renderBooks(docs){grid.innerHTML=docs.length?docs.map(card).join(""):`<div class="empty">کتابی پیدا نشد. عبارت دیگری را جست‌وجو کنید.</div>`;bindCards(docs);updateFavCount()}
function renderFavorites(){
 favoritesMode=true;document.getElementById("sectionTitle").textContent="کتاب‌های مورد علاقه";document.getElementById("sectionEyebrow").textContent="فهرست شخصی شما";notice.textContent=favorites.length?`${favorites.length} کتاب ذخیره شده است.`:"هنوز کتابی ذخیره نکرده‌اید.";loadMore.hidden=true;renderBooks(favorites)
}
async function searchBooks(query, append=false){
 favoritesMode=false;currentQuery=query;if(!append)currentPage=1;
 document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b.dataset.query===query));
 document.getElementById("sectionTitle").textContent=labelFor(query);
 document.getElementById("sectionEyebrow").textContent=query.startsWith("subject:")?"دسته‌بندی کتاب‌ها":"نتایج جست‌وجو";
 notice.className="notice";notice.textContent="در حال دریافت کتاب‌ها...";
 if(!append)grid.innerHTML="";
 loadMore.hidden=true;
 try{
  const params=new URLSearchParams({q:query,page:String(currentPage),limit:"20",fields:"key,title,author_name,first_publish_year,cover_i,edition_key,subject"});
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  let res;
  try { res = await fetch(`${API}?${params.toString()}`, { signal: controller.signal, mode: "cors" }); } finally { clearTimeout(timeout); }
  if(!res.ok)throw new Error("network");
  const data=await res.json();
  const docs=data.docs||[];
  currentDocs=append?currentDocs.concat(docs):docs;
  renderBooks(currentDocs);
  document.getElementById("resultCount").textContent=`${data.numFound||0} نتیجه`;
  notice.textContent=docs.length?`برای این بخش ${data.numFound||docs.length} عنوان پیدا شد.`:"نتیجه‌ای پیدا نشد.";
  loadMore.hidden=docs.length===0 || currentPage*20>Math.min(data.numFound||0,200);
 }catch(err){
  notice.className="notice error";
  notice.textContent="صفحه نتوانست فهرست را داخل خود نمایش دهد. ممکن است بازکردن فایل از پوشهٔ موبایل محدودیت داشته باشد.";
  if(!append)grid.innerHTML=`<div class="empty"><p>برای اینکه جست‌وجو در همین صفحه درست کار کند، دانای باید از یک نشانی وب امن (HTTPS) باز شود؛ بازکردن مستقیم index.html در بعضی موبایل‌ها اجازهٔ دریافت اطلاعات را نمی‌دهد.</p><a class="read-link" href="https://openlibrary.org/search?q=${encodeURIComponent(query)}" target="_blank" rel="noopener">جست‌وجوی همین عبارت در Open Library ↗</a></div>`;
 }
}
function labelFor(q){const map={"subject:fiction":"رمان و داستان","subject:poetry":"شعر و دیوان","subject:history":"کتاب‌های تاریخی","subject:philosophy":"فلسفه","subject:science":"علم و دانش","subject:religion":"کتاب‌های دینی"};return map[q]||"نتایج جست‌وجو"}
function showDetails(doc){
 const title=escapeHtml(doc.title||"کتاب"), author=escapeHtml((doc.author_name||["نویسنده نامشخص"]).join("، "));
 const key=doc.key||"", searchTerm=encodeURIComponent(doc.title||"");
 const readUrl=key?`https://openlibrary.org${key}`:`https://openlibrary.org/search?q=${searchTerm}`;
 const subjects=(doc.subject||[]).slice(0,5).map(escapeHtml).join("، ");
 dialogContent.innerHTML=`<div class="detail">${coverMarkup(doc,true)}<div><h2>${title}</h2><p>نویسنده: ${author}</p><p>سال نشر: ${doc.first_publish_year||"نامشخص"}</p><p>${subjects?`موضوعات: ${subjects}`:"برای این کتاب توضیحات بیشتری ثبت نشده است."}</p><a class="read-link" href="${readUrl}" target="_blank" rel="noopener">مشاهده در کتابخانهٔ آنلاین ↗</a><p>دسترسی به متن کامل یا نسخهٔ امانتی برای هر کتاب متفاوت است.</p></div></div>`;
 dialog.showModal();
}
searchForm.addEventListener("submit",e=>{e.preventDefault();const q=searchInput.value.trim();if(q)searchBooks(q)});
document.querySelectorAll(".category").forEach(btn=>btn.addEventListener("click",()=>{searchInput.value="";searchBooks(btn.dataset.query)}));
document.getElementById("favoritesToggle").addEventListener("click",()=>{if(favoritesMode)searchBooks(currentQuery);else renderFavorites()});
loadMore.addEventListener("click",()=>{currentPage++;searchBooks(currentQuery,true)});
document.getElementById("closeDialog").addEventListener("click",()=>dialog.close());
dialog.addEventListener("click",e=>{if(e.target===dialog)dialog.close()});
updateFavCount();
searchBooks(currentQuery);
